﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SingleControlLibrary.Controls
{
    public class RegLabel:Label
    {

    }
}
