﻿using System.Windows;
using System.Windows.Controls;

namespace DialControlLibrary
{

    public partial class Regulator : UserControl
    {
        public Regulator()
        {
            InitializeComponent();
            this.DefaultSet();
        }

        public int MaxInput
        {
            get { return (int)GetValue(MaxInputProperty); }
            set { SetValue(MaxInputProperty, value); }
        }

        public static readonly DependencyProperty MaxInputProperty =
            DependencyProperty.Register
            ("MaxInput", typeof(int), typeof(Regulator), 
                new PropertyMetadata(50));



        public int MinInput
        {
            get { return (int)GetValue(MinInputProperty); }
            set { SetValue(MinInputProperty, value); }
        }

        public static readonly DependencyProperty MinInputProperty =
            DependencyProperty.Register
            ("MinInput", typeof(int), typeof(Regulator), 
                new PropertyMetadata(-20));



        public int NumOutput
        {
            get { return (int)GetValue(NumOutputProperty); }
            set { SetValue(NumOutputProperty, value); }
        }

        public static readonly DependencyProperty NumOutputProperty =
            DependencyProperty.Register
            ("NumOutput", typeof(int), typeof(Regulator), 
                new PropertyMetadata(15));

        private void DefaultSet()
        {
            MaxInput = 50;
            MinInput = -20;
            NumOutput = 15;
        }

    }
}
